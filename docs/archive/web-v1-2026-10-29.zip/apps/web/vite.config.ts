import { resolve } from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  server: {
    port: 5174,
    strictPort: true,
  },
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        berita: resolve(__dirname, 'berita.html'),
        baca: resolve(__dirname, 'baca.html'),
        peringkat: resolve(__dirname, 'peringkat.html'),
        monster: resolve(__dirname, 'monster.html'),
        admin: resolve(__dirname, 'admin.html'),
      },
    },
  },
});
