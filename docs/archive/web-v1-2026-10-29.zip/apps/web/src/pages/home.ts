import '../styles.css';
import { checkAdminStatus, fetchLeaderboard, fetchNewsList } from '../api';
import { getCurrentUser, signOut } from '../auth';
import { esc, gameUrl } from '../html';
import { categoryLabel, formatDate, newsExcerpt } from '../news';
import { t, webData } from '../text';
import { openAuthModal } from '../ui/auth-modal';
import { renderLayout } from '../ui/layout';
import { monsterCard } from '../ui/monster-card';

async function init() {
  const app = document.getElementById('app');
  if (!app) return;

  const user = await getCurrentUser();
  const admin = user ? await checkAdminStatus() : { isAdmin: false };

  const { contentEl } = renderLayout(app, 'home', {
    signedIn: !!user,
    isAdmin: admin.isAdmin,
    email: user?.email,
    onLogin: () => openAuthModal(() => init()),
    onLogout: () => {
      signOut();
      init();
    },
  });

  const monsterCount = webData.allMonsters.length;
  const tierCount = webData.tiers.length;

  contentEl.innerHTML = `
    <section class="hero-section">
      <div class="hero-sparkles" aria-hidden="true"></div>
      <div class="hero-text">
        <div class="hero-badge">${t('web.home.badge', { monsters: monsterCount, tiers: tierCount })}</div>
        <h1 class="hero-title">${t('web.home.heroTitle')}</h1>
        <p class="hero-subtitle">${t('web.home.heroSubtitle', { monsters: monsterCount, tiers: tierCount })}</p>
        <div class="hero-actions">
          <a href="${esc(gameUrl())}" class="btn-primary hero-btn" target="_blank" rel="noopener noreferrer">${t('web.nav.play')}</a>
          <a href="monster.html" class="btn-secondary hero-btn">${t('web.nav.pedia')}</a>
        </div>
        <p class="hero-note">${t('web.home.playNote')}</p>
      </div>
      <div class="hero-art">
        <img
          src="img/island.webp"
          srcset="img/island-640.webp 640w, img/island.webp 973w"
          sizes="(max-width: 900px) 92vw, 600px"
          alt="${t('web.home.heroAlt')}"
          width="973"
          height="833"
        />
      </div>
    </section>

    <section class="home-section">
      <h2 class="section-title">${t('web.home.pillarsTitle')}</h2>
      <p class="section-subtitle">${t('web.home.pillarsSubtitle')}</p>
      <div class="features-grid">
        ${[
          ['balai-utama', 'Village'],
          ['altar', 'Altar'],
          ['arena', 'Arena'],
        ]
          .map(
            ([img, key]) => `
        <div class="feature-card game-frame">
          <div class="feature-art"><img src="img/${img}.webp" alt="" loading="lazy" /></div>
          <h3 class="feature-title">${t(`web.home.feature${key}Title`)}</h3>
          <p class="feature-desc">${t(`web.home.feature${key}Desc`)}</p>
        </div>`,
          )
          .join('')}
      </div>
    </section>

    <section class="home-section">
      <h2 class="section-title">${t('web.home.galleryTitle')}</h2>
      <p class="section-subtitle">${t('web.home.gallerySubtitle')}</p>
      <div class="gallery-grid">
        ${['desa', 'pedia', 'peta']
          .map(
            (shot) => `
        <figure class="gallery-item game-frame">
          <img src="img/shot-${shot}.webp" alt="${t(`web.home.shot.${shot}`)}" loading="lazy" width="800" height="450" />
          <figcaption>${t(`web.home.shot.${shot}`)}</figcaption>
        </figure>`,
          )
          .join('')}
      </div>
    </section>

    <section class="home-section">
      <h2 class="section-title">${t('web.home.featuredTitle')}</h2>
      <p class="section-subtitle">${t('web.home.featuredSubtitle')}</p>
      <div class="monster-grid featured-grid">
        ${webData.featured.map((m) => monsterCard(m, false, 'monster.html')).join('')}
      </div>
      <div class="section-more"><a href="monster.html">${t('web.home.viewAllMonsters')}</a></div>
    </section>

    <div class="home-columns">
      <div>
        <div class="column-head">
          <h3>${t('web.home.latestNewsTitle')}</h3>
          <a href="berita.html">${t('web.home.viewAllNews')}</a>
        </div>
        <div id="home-news-container">
          <div class="muted-note">${t('web.home.loadingNews')}</div>
        </div>
      </div>

      <div>
        <div class="column-head">
          <h3>${t('web.home.topLeaderboardTitle')}</h3>
          <a href="peringkat.html">${t('web.home.viewAllLeaderboard')}</a>
        </div>
        <div id="home-leaderboard-container">
          <div class="muted-note">${t('web.home.loadingLeaderboard')}</div>
        </div>
      </div>
    </div>
  `;

  const newsContainer = contentEl.querySelector('#home-news-container') as HTMLElement;
  fetchNewsList({ limit: 3 })
    .then((res) => {
      if (!res.ok) {
        newsContainer.innerHTML = `<div class="muted-note">${t('web.home.newsFailed')}</div>`;
        return;
      }
      if (res.items.length === 0) {
        newsContainer.innerHTML = `<div class="card-panel empty-panel">${t('web.home.noNews')}</div>`;
        return;
      }
      newsContainer.innerHTML = res.items
        .map(
          (item) => `
        <a class="card-panel home-news-item" href="baca.html?slug=${encodeURIComponent(item.slug)}">
          <div class="news-meta">
            <span class="tag-badge tag-gold">${categoryLabel(item.category)}</span>
            <span>${formatDate(item.publishedAt)}</span>
          </div>
          <h4>${esc(item.title)}</h4>
          <p>${esc(newsExcerpt(item, 90))}</p>
        </a>
      `,
        )
        .join('');
    })
    .catch(() => {
      newsContainer.innerHTML = `<div class="muted-note">${t('web.home.newsFailed')}</div>`;
    });

  const boardContainer = contentEl.querySelector('#home-leaderboard-container') as HTMLElement;
  fetchLeaderboard(3)
    .then((res) => {
      if (!res.ok) {
        boardContainer.innerHTML = `<div class="muted-note">${t('web.home.leaderboardFailed')}</div>`;
        return;
      }
      if (res.entries.length === 0) {
        boardContainer.innerHTML = `<div class="card-panel empty-panel">${t('web.home.noLeaderboard')}</div>`;
        return;
      }
      boardContainer.innerHTML = `
        <div class="table-scroll">
          <table class="leaderboard-table">
            <tbody>
              ${res.entries
                .map(
                  (row) => `
                <tr>
                  <td class="rank-cell"><span class="rank-badge rank-${row.rank}">${row.rank}</span></td>
                  <td>
                    <div class="player-name">${esc(row.playerName)}</div>
                    <div class="cell-sub">${t('web.common.level', { level: row.level })}</div>
                  </td>
                  <td class="cell-right">
                    <div class="points">${t('web.common.points', { points: row.arenaRating })}</div>
                    <div class="cell-sub">${esc(row.arenaTier)}</div>
                  </td>
                </tr>
              `,
                )
                .join('')}
            </tbody>
          </table>
        </div>
      `;
    })
    .catch(() => {
      boardContainer.innerHTML = `<div class="muted-note">${t('web.home.leaderboardFailed')}</div>`;
    });
}

init();
