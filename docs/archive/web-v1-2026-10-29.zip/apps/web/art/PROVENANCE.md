# Asal-usul gambar website

Website (`apps/web`) boleh memakai SpriteCook (keputusan pemilik 2026-10-29); game tetap memakai gambar buatan kode. Semua gambar orisinal dan mengikuti skill `soul-monster-art-style`.

| File                                                      | Sumber                                                                        |
| --------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `public/img/island.webp`, `island-640.webp`, `sky.webp`   | SpriteCook, lihat `spritecook-assets.json`                                    |
| `public/img/balai-utama.webp`, `altar.webp`, `arena.webp` | Salinan kecil dari `apps/game/art/buildings/<id>/lv1.png` (aset game sendiri) |
| `public/img/shot-*.webp`                                  | Tangkapan layar game (`apps/game`) mode offline                               |
| `public/favicon.png`                                      | Salinan `apps/game/public/icons/icon-192.png`                                 |

## Prompt hero (SpriteCook, 8 kredit)

`generate_game_art`: `pixel=false`, `model="gpt-image-2.5-flare"`, `resolution="1K"`, `quality="medium"`, `aspect_ratio="1:1"`, `bg_mode="include"`, palet UI + alam dari skill gaya seni. Format 16:9 butuh 14 kredit (render 2K), jadi dipakai 1:1.

Ringkas: ilustrasi utama website — desa di pulau melayang tampak isometrik 3/4: balai utama beratap merah berhias emas, altar kristal ungu bercahaya, arena pasir bundar berpanji ungu-emas, rumah kecil, pohon, taman bunga, air terjun dari tepi pulau; monster chibi (slime air biru, rubah api berekor api, makhluk daun hijau, naga ungu kecil terbang); langit senja ungu dengan cahaya emas, pulau kecil di kiri-kanan, kilau sihir; cahaya kiri atas, garis tepi gelap tipis, tanpa teks/logo/UI; desain orisinal.

Sumber mentah `art/hero-raw.png` (1024 px PNG) disimpan. Dari situ dibuat dua gambar website:

- **Pulau** (`island.webp`): `remove_background` SpriteCook (1 kredit) → `art/island-cutout-raw.png`; hanya pulau utama dan naga yang disimpan, lalu dipangkas.
- **Langit** (`sky.webp`): area pulau dihapus dari gambar asli, lubangnya diisi warna langit sekitar, lalu dihaluskan. Dipakai sebagai latar semua halaman.
